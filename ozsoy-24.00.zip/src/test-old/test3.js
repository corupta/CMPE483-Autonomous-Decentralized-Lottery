(function test3(){
  helpers(true, "hello");
})();