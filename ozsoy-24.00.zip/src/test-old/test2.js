(function test2(){
  helpers(eip20ContractAddress === "", "hello");
})();