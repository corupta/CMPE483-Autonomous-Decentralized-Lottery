(function test1(){
  var john = newAccount();




  helpers(true, "hello");
})();